function fahenreit(number) {
   number = parseFloat(number);
   document.getElementById("celsius").innerHTML = Math.floor((number - 32) * (5 / 9));
}

function celsius(number) {
   number = parseFloat(number);
   document.getElementById("fahenreit").innerHTML = Math.floor((number * (9 / 5) + 32));
}

function kelvin(number) {
   number = parseFloat(number);
   document.getElementById("kelvin").innerHTML = Math.floor((number - 273.15));
}